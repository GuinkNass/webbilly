// ==============================================================================
// Billy Hunter — WhatsApp Web Webpack Hook & Native Store Bridge
// Injetado no Main World da página web.whatsapp.com
// ==============================================================================

(function () {
  console.log('[Billy WhatsApp Inject] Carregado no contexto principal.');

  let reqModule = null;
  let MsgStore = null;
  let ChatStore = null;
  let ChatPresence = null;
  let sendMsgModule = null;

  function findModule(predicate) {
    if (!reqModule || !reqModule.c) return null;
    for (const id in reqModule.c) {
      const mod = reqModule.c[id];
      if (!mod || !mod.exports) continue;
      const exp = mod.exports;
      try {
        if (predicate(exp)) return exp;
        if (exp.default && predicate(exp.default)) return exp.default;
      } catch (e) {}
    }
    return null;
  }

  function extractStores() {
    try {
      if (!MsgStore) {
        MsgStore = findModule((exp) => exp.MsgStore || (exp.models && exp._events && exp._events['add']));
        if (MsgStore && MsgStore.MsgStore) MsgStore = MsgStore.MsgStore;
      }

      if (!ChatStore) {
        ChatStore = findModule((exp) => exp.ChatStore || (exp.getActiveChat && exp.models));
        if (ChatStore && ChatStore.ChatStore) ChatStore = ChatStore.ChatStore;
      }

      if (!ChatPresence) {
        ChatPresence = findModule((exp) => (typeof exp.markComposing === 'function' && typeof exp.markPaused === 'function') || exp.ChatPresence);
        if (ChatPresence && ChatPresence.ChatPresence) ChatPresence = ChatPresence.ChatPresence;
      }

      if (!sendMsgModule) {
        sendMsgModule = findModule((exp) => typeof exp.addAndSendMsgToChat === 'function' || typeof exp.sendMsgOrExecute === 'function' || typeof exp.SendTextMsgToChat === 'function');
      }

      if (MsgStore) {
        attachMsgListener();
      }
    } catch (err) {
      console.warn('[Billy Inject] Erro na extração de módulos:', err);
    }
  }

  function initWebpackHook() {
    window.webpackChunkwhatsapp_web_client = window.webpackChunkwhatsapp_web_client || [];
    
    // Injeção de chunk temporário para capturar require
    const chunkId = 'billy_injector_' + Date.now();
    try {
      window.webpackChunkwhatsapp_web_client.push([
        [chunkId],
        {},
        function (r) {
          reqModule = r;
        }
      ]);
      extractStores();
    } catch (e) {
      console.warn('[Billy Inject] Falha ao injetar chunk direto:', e);
    }

    // Monitora novos chunks carregados
    const originalPush = window.webpackChunkwhatsapp_web_client.push.bind(window.webpackChunkwhatsapp_web_client);
    window.webpackChunkwhatsapp_web_client.push = function (...args) {
      const res = originalPush(...args);
      if (!MsgStore || !sendMsgModule) {
        extractStores();
      }
      return res;
    };

    // Polling de redundância nos primeiros 15s para garantir inicialização tardia
    let attempts = 0;
    const interval = setInterval(() => {
      attempts++;
      if (MsgStore && sendMsgModule) {
        clearInterval(interval);
      } else {
        extractStores();
      }
      if (attempts >= 15) clearInterval(interval);
    }, 1000);
  }

  function attachMsgListener() {
    if (!MsgStore || MsgStore._billyAttached) return;
    MsgStore._billyAttached = true;
    console.log('[Billy Inject] Ouvindo eventos de novas mensagens no MsgStore...');

    const onMessageAdd = async (msg) => {
      try {
        if (!msg) return;

        // Descarte de mensagens próprias (fromMe === true)
        const isFromMe = Boolean(msg.fromMe || (msg.id && msg.id.fromMe));
        if (isFromMe) return;

        const remoteJid = msg.id ? (msg.id.remote?._serialized || msg.id.remote) : (msg.from?._serialized || msg.from);
        const cleanPhone = (remoteJid || '').replace(/@.*$/, '');

        // Verificação se é imagem / mídia recebida
        const isImage = msg.type === 'image' || (msg.mimetype && msg.mimetype.startsWith('image/'));
        if (isImage) {
          let base64 = '';
          if (typeof msg.downloadMedia === 'function') {
            try {
              const media = await msg.downloadMedia();
              if (media && media.data) {
                base64 = media.data;
              }
            } catch (err) {
              console.warn('[Billy Inject] Falha ao extrair imagem via downloadMedia:', err);
            }
          }
          if (!base64 && msg.mediaData) {
            base64 = msg.mediaData.preview?._b64 || msg.mediaData.preview || '';
          }

          window.postMessage({
            type: 'BILLY_IMAGE_RECEIVED',
            chatId: remoteJid,
            phone: cleanPhone,
            base64: base64,
            caption: msg.caption || '',
            timestamp: msg.t || Date.now()
          }, '*');
          return;
        }

        // Mensagem de texto convencional
        const textContent = msg.body || msg.caption || '';
        if (textContent && textContent.trim()) {
          window.postMessage({
            type: 'BILLY_INCOMING_MSG',
            chatId: remoteJid,
            phone: cleanPhone,
            text: textContent,
            timestamp: msg.t || Date.now()
          }, '*');
        }
      } catch (err) {
        console.error('[Billy Inject] Erro no listener onMessageAdd:', err);
      }
    };

    if (typeof MsgStore.on === 'function') {
      MsgStore.on('add', onMessageAdd);
    }
  }

  // Monitora alterações do chat ativo (conversa selecionada na lista)
  let lastActiveJid = null;
  function checkActiveChat() {
    try {
      let activeJid = null;
      let activeName = '';
      let phone = '';

      if (ChatStore && typeof ChatStore.getActiveChat === 'function') {
        const activeChat = ChatStore.getActiveChat();
        if (activeChat && activeChat.id) {
          activeJid = activeChat.id._serialized || activeChat.id;
          activeName = activeChat.formattedTitle || activeChat.name || '';
          phone = (activeChat.id.user || activeJid || '').replace(/@.*$/, '').replace(/\D/g, '');
        }
      }

      if (!activeJid || !phone) {
        // Fallback DOM para detectar conversa aberta
        const mainHeader = document.querySelector('#main header');
        if (mainHeader) {
          const titleEl = mainHeader.querySelector('span[title], span[dir="auto"], div[role="button"] span');
          activeName = titleEl ? (titleEl.getAttribute('title') || titleEl.innerText || '').trim() : '';
          const phoneMatch = activeName.match(/\+?\d[\d\s-]{7,}\d/);
          if (phoneMatch) {
            phone = phoneMatch[0].replace(/\D/g, '');
          }
        }

        // Se o contato estiver salvo por nome (ex: "klock"), extrai o telefone diretamente das mensagens do DOM
        if (!phone) {
          const msgNodes = document.querySelectorAll('#main div[data-id], #main [data-id*="@c.us"], #main [data-id*="@s.whatsapp.net"]');
          for (const node of msgNodes) {
            const mId = node.getAttribute('data-id') || '';
            const match = mId.match(/(?:true|false)_(\d{10,15})@(c\.us|s\.whatsapp\.net)/);
            if (match) {
              phone = match[1];
              break;
            }
          }
        }

        if (!activeJid) {
          activeJid = phone ? `${phone}@c.us` : (activeName || 'active_chat');
        }
      }

      if (activeJid && activeJid !== lastActiveJid) {
        lastActiveJid = activeJid;
        window.postMessage({
          type: 'BILLY_ACTIVE_CHAT_CHANGED',
          phone,
          name: activeName,
          jid: activeJid
        }, '*');
      }
    } catch (e) {}
  }

  setInterval(checkActiveChat, 1200);

  // Fallback de envio seguro via simulação DOM caso a versão do WhatsApp Web mude assinaturas internas
  async function sendViaDOM(text) {
    try {
      const input = document.querySelector('footer div[contenteditable="true"]') ||
                    document.querySelector('div[contenteditable="true"][data-tab="10"]') ||
                    document.querySelector('div[role="textbox"]');

      if (!input) return false;

      input.focus();
      document.execCommand('selectAll', false, null);
      document.execCommand('delete', false, null);
      document.execCommand('insertText', false, text);

      input.dispatchEvent(new InputEvent('input', { bubbles: true }));

      await new Promise(r => setTimeout(r, 400));

      const sendBtn = document.querySelector('button[aria-label="Enviar"]') ||
                      document.querySelector('button[data-testid="send"]') ||
                      document.querySelector('span[data-icon="send"]')?.closest('button');

      if (sendBtn) {
        sendBtn.click();
        return true;
      }

      // Simula Enter caso botão não esteja acessível
      const enterEvent = new KeyboardEvent('keydown', {
        key: 'Enter',
        code: 'Enter',
        keyCode: 13,
        which: 13,
        bubbles: true
      });
      input.dispatchEvent(enterEvent);
      return true;
    } catch (e) {
      console.warn('[Billy Inject] Fallback DOM de envio falhou:', e);
      return false;
    }
  }

  // Listener para ordens de envio vindas do Content Script
  window.addEventListener('message', async (event) => {
    if (!event.data) return;

    // Envio instantâneo (Disparado por clique no botão de Enviar Demo ou Resposta Rápida)
    if (event.data.type === 'BILLY_SEND_INSTANT') {
      const { chatId, text } = event.data;
      if (!text || !text.trim()) return;

      console.log(`[Billy Inject] Executando envio instantâneo para ${chatId || 'chat ativo'}...`);

      let sent = false;
      let chat = null;
      if (ChatStore) {
        if (chatId) {
          if (typeof ChatStore.get === 'function') chat = ChatStore.get(chatId);
          else if (Array.isArray(ChatStore.models)) chat = ChatStore.models.find(c => (c.id?._serialized || c.id) === chatId);
        }
        if (!chat && typeof ChatStore.getActiveChat === 'function') {
          chat = ChatStore.getActiveChat();
        }
      }

      if (sendMsgModule && chat) {
        try {
          if (typeof sendMsgModule.addAndSendMsgToChat === 'function') {
            await sendMsgModule.addAndSendMsgToChat(chat, text);
            sent = true;
          } else if (typeof sendMsgModule.sendMsgOrExecute === 'function') {
            await sendMsgModule.sendMsgOrExecute(chat, text);
            sent = true;
          } else if (typeof sendMsgModule.SendTextMsgToChat === 'function') {
            await sendMsgModule.SendTextMsgToChat(chat, text);
            sent = true;
          }
        } catch (sendErr) {
          console.warn('[Billy Inject] Falha no envio instantâneo via módulo nativo:', sendErr);
        }
      }

      if (!sent) {
        sent = await sendViaDOM(text);
      }

      window.postMessage({
        type: 'BILLY_INSTANT_SENT',
        chatId: chatId || (chat?.id?._serialized),
        success: sent
      }, '*');
      return;
    }

    if (event.data.type !== 'BILLY_SEND_REPLY') return;

    const { chatId, text } = event.data;
    if (!text || !text.trim()) return;

    console.log(`[Billy Inject] Processando envio para ${chatId}: "${text.slice(0, 40)}..."`);

    try {
      // 1. Simulação de digitação humana (markComposing)
      if (ChatPresence && typeof ChatPresence.markComposing === 'function') {
        try {
          ChatPresence.markComposing(chatId);
        } catch (e) {}
      }

      // 2. Delay humanizado entre 3.0s e 5.5s
      const delayMs = Math.floor(Math.random() * (5500 - 3000 + 1)) + 3000;
      await new Promise(r => setTimeout(r, delayMs));

      // 3. Finalizar digitação (markPaused)
      if (ChatPresence && typeof ChatPresence.markPaused === 'function') {
        try {
          ChatPresence.markPaused(chatId);
        } catch (e) {}
      }

      // 4. Envio pelo módulo nativo
      let sent = false;
      let chat = null;
      if (ChatStore) {
        if (typeof ChatStore.get === 'function') {
          chat = ChatStore.get(chatId);
        } else if (Array.isArray(ChatStore.models)) {
          chat = ChatStore.models.find(c => (c.id?._serialized || c.id) === chatId);
        }
      }

      if (sendMsgModule && chat) {
        try {
          if (typeof sendMsgModule.addAndSendMsgToChat === 'function') {
            await sendMsgModule.addAndSendMsgToChat(chat, text);
            sent = true;
          } else if (typeof sendMsgModule.sendMsgOrExecute === 'function') {
            await sendMsgModule.sendMsgOrExecute(chat, text);
            sent = true;
          } else if (typeof sendMsgModule.SendTextMsgToChat === 'function') {
            await sendMsgModule.SendTextMsgToChat(chat, text);
            sent = true;
          }
        } catch (sendErr) {
          console.warn('[Billy Inject] Erro no envio pelo módulo interno:', sendErr);
        }
      }

      // 5. Fallback via DOM caso módulo falhe
      if (!sent) {
        sent = await sendViaDOM(text);
      }

      window.postMessage({
        type: 'BILLY_REPLY_SENT',
        chatId: chatId,
        success: sent
      }, '*');
    } catch (err) {
      console.error('[Billy Inject] Erro crítico no envio de resposta:', err);
      await sendViaDOM(text);
    }
  });

  // Dispara inicialização do gancho Webpack
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initWebpackHook);
  } else {
    initWebpackHook();
  }
})();
