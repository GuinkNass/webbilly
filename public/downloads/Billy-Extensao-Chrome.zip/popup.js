document.addEventListener('DOMContentLoaded', async () => {
  const statusEl = document.getElementById('server-status');
  const btnOpenMaps = document.getElementById('btn-open-maps');
  const btnStartScrape = document.getElementById('btn-start-scrape');
  const btnTabQuery = document.getElementById('btn-tab-query');
  const queryInput = document.getElementById('search-query');
  const depthSelect = document.getElementById('select-depth');
  const progressBox = document.getElementById('progress-box');
  const progressText = document.getElementById('progress-text');

  let isServerOnline = false;

  async function callBilly(endpoint, body = null, method = 'POST') {
    const url = `http://127.0.0.1:5200${endpoint}`;
    const options = {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined
    };

    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
      try {
        const resp = await new Promise((resolve) => {
          chrome.runtime.sendMessage({ type: 'BILLY_FETCH', url, options }, (response) => {
            if (chrome.runtime.lastError) {
              resolve({ ok: false, error: chrome.runtime.lastError.message });
            } else {
              resolve(response || { ok: false, error: 'Sem resposta' });
            }
          });
        });
        if (resp && resp.ok) return resp.data;
        if (resp && resp.error) throw new Error(resp.error);
      } catch (e) {
        console.warn('Fallback to direct fetch:', e);
      }
    }

    const res = await fetch(url, options);
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || `Status ${res.status}`);
    }
    return await res.json();
  }

  // 1. Verifica integridade do Billy Desktop
  async function checkServerHealth() {
    try {
      const data = await callBilly('/api/health', null, 'GET');
      if (data && data.status === 'ok') {
        isServerOnline = true;
        statusEl.innerHTML = `<span class="dot online"></span> Conectado (${data.leadsCount || 0} leads)`;
        statusEl.style.color = '#34d399';
        btnStartScrape.disabled = false;
      } else {
        throw new Error('Servidor não pronto');
      }
    } catch (e) {
      isServerOnline = false;
      statusEl.innerHTML = '<span class="dot offline"></span> Offline (Abra o Billy Desktop)';
      statusEl.style.color = '#f87171';
      btnStartScrape.disabled = true;
    }
  }

  await checkServerHealth();

  // 2. Detecta se a aba ativa é o Google Maps e extrai a pesquisa
  try {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0] && tabs[0].url) {
        const url = tabs[0].url;
        if (url.includes('google.com/maps')) {
          let detectedQuery = '';

          // Padrão 1: /maps/search/nicho+cidade/
          const matchSearch = url.match(/\/maps\/search\/([^/@?]+)/);
          if (matchSearch && matchSearch[1]) {
            detectedQuery = decodeURIComponent(matchSearch[1].replace(/\+/g, ' '));
          } else {
            // Padrão 2: parâmetro ?q= ou ?query=
            const urlObj = new URL(url);
            detectedQuery = urlObj.searchParams.get('q') || urlObj.searchParams.get('query') || '';
          }

          if (detectedQuery && detectedQuery.trim().length > 1) {
            btnTabQuery.style.display = 'inline-flex';
            btnTabQuery.innerHTML = `📍 Usar pesquisa desta aba: <strong>${detectedQuery}</strong>`;
            btnTabQuery.addEventListener('click', () => {
              queryInput.value = detectedQuery;
              btnTabQuery.style.display = 'none';
            });
          }
        }
      }
    });
  } catch (e) {}

  // 3. Dispara a mineração via Gosom Scraper no Billy Server
  btnStartScrape.addEventListener('click', async () => {
    const query = queryInput.value.trim();
    if (!query) {
      alert('Por favor, informe o nicho e a localização desejada (ex: estúdios de tatuagem pinheiros sp).');
      queryInput.focus();
      return;
    }

    if (!isServerOnline) {
      alert('O aplicativo Billy Desktop não foi detectado na porta 5200. Abra o app Billy no computador antes de iniciar a mineração.');
      return;
    }

    const depth = parseInt(depthSelect.value, 10) || 1;

    btnStartScrape.disabled = true;
    btnStartScrape.innerHTML = '<span class="spinner"></span> <span>Minerando...</span>';
    progressBox.classList.add('active');
    progressText.innerHTML = `
      <span class="spinner"></span> 
      <span>Iniciando motor Gosom no Billy para <strong>"${query}"</strong>...</span>
    `;

    try {
      const result = await callBilly('/api/scraper/google-maps', {
        query,
        depth,
        concurrency: 2,
        lang: 'pt'
      });

      progressText.innerHTML = `
        <span style="color: #34d399; font-weight: bold;">✅ Sucesso!</span><br/>
        <strong>${result.count || 0}</strong> estabelecimentos encontrados.<br/>
        <strong>${result.imported || 0}</strong> novos leads qualificados salvos no seu painel Billy!
      `;

      btnStartScrape.innerHTML = '<span>✅ Mineração Concluída!</span>';
      setTimeout(() => {
        btnStartScrape.disabled = false;
        btnStartScrape.innerHTML = '<span>🚀 Minerar Mais Leads</span>';
        checkServerHealth();
      }, 3500);

    } catch (err) {
      progressText.innerHTML = `
        <span style="color: #f87171; font-weight: bold;">⚠️ Falha na Mineração</span><br/>
        ${err.message}
      `;
      btnStartScrape.disabled = false;
      btnStartScrape.innerHTML = '<span>Tentar Novamente</span>';
    }
  });

  // 4. Botão para abrir o Maps
  btnOpenMaps.addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://www.google.com/maps' });
  });
});
