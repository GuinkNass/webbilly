// ==============================================================================
// 60 Respostas Prontas Oficiais do Billy Suite (Venda, SAC e Pós-Venda)
// Zero emojis, links isolados por \n\n, substituição dinâmica de {{empresa}}, etc.
// ==============================================================================

const QUICK_REPLIES = {
  VENDA: [
    {
      id: 'venda-01',
      title: '01. Abertura com Previa Pronta',
      text: `Olá, {{empresa}}! Tudo bem?\n\nNossa equipe analisou o perfil de vocês e tomou a iniciativa de montar uma prévia exclusiva e funcional do site oficial da marca, já adaptada para celulares e pronta para receber clientes do Google:\n\n{{demoUrl}}\n\nHoje, quem busca pelos seus serviços pesquisa primeiro no Google. Ter essa página no ar permite que vocês apareçam nas buscas da região, passem mais autoridade imediata e possam anunciar no Google Ads para captar clientes todos os dias.\n\nComo o projeto já está estruturado, preparamos duas formas simples de colocar no ar hoje mesmo:\n\n*Opção 1: Plano Mensal (Sem investimento inicial)*\n- Endereço: {{subdominio}}\n- Benefícios: zero taxa de criação, sem fidelidade, suporte técnico incluso e até 2 alterações simples por mês inclusas.\n- Investimento: R$ 29,90/mês.\n\n*Opção 2: Pacote Completo (Site Completo + Domínio Próprio por 1 Ano)*\n- Endereço: seu domínio próprio exclusivo (.com.br) liberado por 1 ano completo por R$ 490,00 (pagamento único, sem mensalidade obrigatória).\n- Renovação anual de apenas R$ 70,00/ano e atualizações avulsas sob demanda por R$ 29,90.\n\nO que achou do visual que montamos para vocês?`
    },
    {
      id: 'venda-02',
      title: '02. Por que ter site alem do Instagram',
      text: `O Instagram é ótimo para relacionamento, mas depende do algoritmo e não aparece quando alguém pesquisa pelo seu serviço no Google da sua região.\n\nCom o site oficial no ar, você captura justamente o cliente que já está procurando para contratar agora e direciona ele direto para o seu WhatsApp.`
    },
    {
      id: 'venda-03',
      title: '03. Vantagem contra Agencias Tradicionais',
      text: `Uma agência tradicional cobra entre R$ 2.000,00 e R$ 5.000,00 e leva de 30 a 45 dias para entregar um site.\n\nNa Webbilly, nós já construímos a sua estrutura antecipadamente. Você valida o visual pronto antes de pagar e coloca no ar hoje mesmo por apenas R$ 29,90/mês sem taxa de criação.`
    },
    {
      id: 'venda-04',
      title: '04. Vantagem contra Linktree e Bio',
      text: `Agregadores de link como Linktree não passam autoridade comercial, não ranqueiam bem nas buscas locais do Google e não permitem estruturar campanhas profissionais de Google Ads.\n\nUma landing page própria apresenta seus diferenciais, avaliações reais e botões de conversão focados em fechar vendas.`
    },
    {
      id: 'venda-05',
      title: '05. Vantagem contra Wix e Faca Voce Mesmo',
      text: `Ferramentas de criar site sozinho exigem horas de configuração, ajustes no celular, compra de hospedagem e manutenção técnica.\n\nConosco você não perde tempo com nada técnico: nossa equipe já entrega tudo montado, hospedado, seguro e pronto para vender.`
    },
    {
      id: 'venda-06',
      title: '06. Pronto para Anunciar no Google Ads',
      text: `Se vocês quiserem anunciar no Google Ads para aparecer no topo das pesquisas do bairro ou da cidade, precisam de uma página rápida e focada em conversão.\n\nA estrutura que montamos já está otimizada para receber tráfego pago e transformar cliques em mensagens no seu WhatsApp.`
    },
    {
      id: 'venda-07',
      title: '07. Autoridade e Avaliacoes Reais',
      text: `Quando um cliente novo pesquisa o nome da sua empresa no Google antes de fechar negócio, encontrar um site oficial bem estruturado elimina a desconfiança na hora.\n\nAlém disso, destacamos a reputação e as avaliações reais de vocês para aumentar a taxa de fechamento.`
    },
    {
      id: 'venda-08',
      title: '08. Zero Risco e Sem Fidelidade',
      text: `No Plano Mensal de R$ 29,90/mês você não paga taxa de criação, não paga multa de cancelamento e não fica preso a contrato de fidelidade.\n\nVocê coloca o site no ar hoje, testa o retorno na prática e permanece apenas enquanto fizer sentido para o seu negócio.`
    },
    {
      id: 'venda-09',
      title: '09. Retorno sobre Investimento (ROI)',
      text: `Pense na conta simples: o plano mensal custa R$ 29,90 por mês inteiro — menos de R$ 1,00 por dia.\n\nApenas um único cliente novo que encontrar vocês pelo Google já paga vários meses da assinatura e gera lucro líquido para a empresa.`
    },
    {
      id: 'venda-10',
      title: '10. Resumo Opcao 1 vs Opcao 2',
      text: `Para facilitar a escolha, veja a diferença direta entre os dois formatos:\n\n*Opção 1 (Plano Mensal - R$ 29,90/mês):* Você usa o endereço {{subdominio}}, sem taxa inicial, com hospedagem, suporte e até 2 alterações simples/mês inclusas.\n\n*Opção 2 (Pacote Completo 1 Ano - R$ 490,00 único):* Você registra seu domínio próprio exclusivo (ex: suaempresa.com.br), recebe a estrutura liberada por 1 ano sem mensalidade de plataforma (renovação anual de apenas R$ 70,00/ano e atualizações avulsas sob demanda por R$ 29,90).`
    },
    {
      id: 'venda-11',
      title: '11. Velocidade e Foco no Celular',
      text: `Hoje mais de 90% das pesquisas locais são feitas pelo celular.\n\nA página que preparamos foi desenhada primeiro para smartphones, com carregamento instantâneo e botões estratégicos que abrem o WhatsApp de vocês com um toque.`
    },
    {
      id: 'venda-12',
      title: '12. Hospedagem e Seguranca SSL Inclusos',
      text: `Você não precisa contratar servidor separado nem se preocupar com certificado de segurança.\n\nTanto a hospedagem de alta velocidade quanto o cadeado de segurança HTTPS já estão totalmente inclusos na estrutura.`
    },
    {
      id: 'venda-13',
      title: '13. Protecao de Marca no Google',
      text: `Mesmo que vocês já tenham uma boa carteira de clientes por indicação, quando alguém pesquisa o nome da sua empresa no Google e não acha um site oficial, acaba clicando no anúncio do concorrente.\n\nTer sua página no ar protege a sua marca e garante que o cliente chegue até vocês.`
    },
    {
      id: 'venda-14',
      title: '14. Objecao: Vou pensar / Ver depois',
      text: `Sem problemas! Como a prévia de vocês já está pronta e publicada neste link, aproveite para abrir no celular e mostrar para sua equipe:\n\n{{demoUrl}}\n\nAssim que decidirem ativar, é só me chamar aqui que liberamos no mesmo dia.`
    },
    {
      id: 'venda-15',
      title: '15. Objecao: Esta caro / Sem verba agora',
      text: `Justamente pensando em não pesar no caixa inicial da empresa é que criamos a Opção 1 sem taxa de criação.\n\nPor R$ 29,90/mês você já coloca uma vitrine profissional no ar hoje mesmo, sem precisar desembolsar centenas de reais na entrada.`
    },
    {
      id: 'venda-16',
      title: '16. Link de Ativacao Opcao 1 (Mensal)',
      text: `Perfeito! Para ativar agora mesmo o Plano Mensal de R$ 29,90/mês sem taxa de criação, basta acessar o link oficial da sua proposta abaixo:\n\n{{propostaUrl}}\n\nAssim que confirmar, nossa equipe já ativa o seu endereço oficial no ar.`
    },
    {
      id: 'venda-17',
      title: '17. Link de Ativacao Opcao 2 (Pacote Completo 1 Ano)',
      text: `Excelente escolha! Para garantir o seu Pacote Completo com Domínio Próprio por 1 Ano por R$ 490,00 (pagamento único, sem mensalidade obrigatória), acesse o link oficial abaixo:\n\n{{propostaUrl}}\n\nApós a confirmação, já iniciamos o registro e a configuração no seu domínio exclusivo.`
    },
    {
      id: 'venda-18',
      title: '18. Follow-up 24h (Sem Resposta)',
      text: `Olá, {{empresa}}! Passando apenas para confirmar se vocês conseguiram visualizar a prévia do site que nossa equipe montou para vocês:\n\n{{demoUrl}}\n\nFico à disposição se quiserem ajustar algum detalhe ou ativar hoje mesmo.`
    },
    {
      id: 'venda-19',
      title: '19. Follow-up 48h (Ultima Chamada)',
      text: `Olá, {{empresa}}! Nossa equipe técnica está atualizando a fila de demonstrações desta semana e notei que a prévia de vocês ainda está ativa.\n\nVocês têm interesse em colocar essa página no ar no plano de R$ 29,90/mês ou prefere que eu libere o endereço para outro comércio da região?`
    },
    {
      id: 'venda-20',
      title: '20. Fechamento e Prazo de Publicacao',
      text: `Assim que o pagamento for confirmado pelo sistema, sua página já entra no ar oficialmente em até 24 horas úteis e você recebe o link final para colocar no Google e no Instagram.`
    }
  ],
  SAC: [
    {
      id: 'sac-01',
      title: '01. Boas-vindas Atendimento SAC',
      text: `Olá! Bem-vindo ao suporte da Webbilly.\n\nPara agilizar seu atendimento, por favor me informe o nome da empresa ou o link do seu site cadastrado.`
    },
    {
      id: 'sac-02',
      title: '02. Como funciona o pagamento',
      text: `O pagamento da assinatura mensal (R$ 29,90/mês com até 2 alterações inclusas) ou do pacote completo com domínio próprio por 1 ano (R$ 490,00) é realizado diretamente pelo link oficial da sua proposta, com liberação rápida após a compensação.`
    },
    {
      id: 'sac-03',
      title: '03. Prazo de ativacao apos pagamento',
      text: `Após a confirmação do pagamento, a publicação oficial do seu subdomínio ocorre em até 24 horas úteis.`
    },
    {
      id: 'sac-04',
      title: '04. Duvida sobre fidelidade e multa',
      text: `O plano mensal de R$ 29,90/mês não possui contrato de fidelidade nem multa de cancelamento. Você tem total liberdade para cancelar quando desejar.`
    },
    {
      id: 'sac-05',
      title: '05. Como solicitar cancelamento',
      text: `Para solicitar o cancelamento da assinatura mensal sem cobrança do próximo ciclo, basta enviar sua solicitação com pelo menos 5 dias de antecedência do vencimento para nosso canal oficial:\n\nsac@webbilly.com.br`
    },
    {
      id: 'sac-06',
      title: '06. Site nao abre ou parece desatualizado',
      text: `Quando fazemos uma atualização recente, o navegador do celular pode manter a versão antiga salva na memória.\n\nPor favor, teste abrir o link em uma aba anônima ou limpe o cache do navegador. Se persistir, nos avise aqui que verificamos na hora.`
    },
    {
      id: 'sac-07',
      title: '07. Erro ao colocar link no Instagram',
      text: `Para o link funcionar corretamente na bio do Instagram, copie o endereço completo começando com https:// e cole no campo "Site" ao editar seu perfil, sem espaços antes ou depois.`
    },
    {
      id: 'sac-08',
      title: '08. Botao do WhatsApp com numero errado',
      text: `Vamos corrigir isso imediatamente. Por favor, me confirme exatamente qual número com DDD deve receber as mensagens dos botões do site.`
    },
    {
      id: 'sac-09',
      title: '09. Esqueci qual e o link do meu site',
      text: `O endereço oficial do seu site ativo é:\n\n{{subdominio}}\n\nRecomendamos salvar esse link nos favoritos e adicioná-lo no seu perfil do Google e Instagram.`
    },
    {
      id: 'sac-10',
      title: '10. Duvida sobre dominio proprio (.com.br)',
      text: `No plano mensal de R$ 29,90/mês, seu site funciona no subdomínio oficial ({{subdominio}}) com até 2 alterações simples/mês inclusas.\n\nCaso deseje utilizar um domínio próprio exclusivo (ex: suaempresa.com.br) sem mensalidade de plataforma, você pode migrar para a Opção 2 por R$ 490,00 (válido por 1 ano completo, com renovação anual de apenas R$ 70,00/ano e atualizações avulsas sob demanda por R$ 29,90).`
    },
    {
      id: 'sac-11',
      title: '11. Migracao do Mensal para Pacote 1 Ano',
      text: `Você pode migrar do plano mensal de R$ 29,90 para o Pacote Completo com Domínio Próprio por 1 Ano (R$ 490,00 pagamento único) a qualquer momento. Assim que o upgrade é concluído, cancelamos a recorrência mensal e seu site passa a responder no seu domínio exclusivo.`
    },
    {
      id: 'sac-12',
      title: '12. Duvida sobre gestao de Google Ads',
      text: `Nós entregamos a sua landing page totalmente pronta, rápida e estruturada para receber anúncios.\n\nA criação da conta de anúncios e o investimento diário no Google Ads são gerenciados diretamente por você ou pelo seu gestor de tráfego.`
    },
    {
      id: 'sac-13',
      title: '13. Posicionamento nas buscas do Google',
      text: `Sua página já é publicada com estrutura otimizada para ser lida pelo Google. O aparecimento nas buscas orgânicas acontece de forma gradual conforme o Google indexa o link e sua empresa recebe acessos e avaliações.`
    },
    {
      id: 'sac-14',
      title: '14. Correcao urgente de telefone ou endereco',
      text: `Correções de dados cadastrais críticos, como telefone de contato ou endereço físico, têm prioridade no nosso suporte. Envie os dados corretos aqui que já encaminhamos para ajuste.`
    },
    {
      id: 'sac-15',
      title: '15. Orientacao para envio de fotos',
      text: `Para que seu site fique com visual profissional, envie as fotos originais em boa resolução (evite prints de tela com barras pretas ou ícones por cima) e indique em qual seção deseja aplicá-las.`
    },
    {
      id: 'sac-16',
      title: '16. Duvida sobre contas de e-mail',
      text: `O plano mensal de R$ 29,90 contempla exclusivamente o desenvolvimento, hospedagem e manutenção da sua landing page no subdomínio oficial, não incluindo caixas de e-mail personalizadas.`
    },
    {
      id: 'sac-17',
      title: '17. Segunda via ou comprovante financeiro',
      text: `Para questões relacionadas a faturas, segunda via ou recibos de pagamento, envie sua solicitação com o nome da empresa para nosso setor financeiro:\n\nfinanceiro@webbilly.com.br`
    },
    {
      id: 'sac-18',
      title: '18. Atraso na mensalidade e suspensao',
      text: `Caso ocorra atraso superior a 5 dias na mensalidade, o subdomínio entra em suspensão temporária automática.\n\nAssim que o pagamento é regularizado, o site volta ao ar normalmente com todo o conteúdo preservado.`
    },
    {
      id: 'sac-19',
      title: '19. Registro de chamado tecnico',
      text: `Registrei sua solicitação e encaminhei para nossa equipe técnica analisar. O prazo padrão de retorno é de até 1 dia útil, podendo também acompanhar pelo e-mail:\n\nsac@webbilly.com.br`
    },
    {
      id: 'sac-20',
      title: '20. Encerramento de atendimento SAC',
      text: `Sua solicitação foi concluída com sucesso. Caso precise de qualquer outro suporte no futuro, nossa equipe segue à disposição.`
    }
  ],
  POS: [
    {
      id: 'pos-01',
      title: '01. Boas-vindas Pos-Venda + Link Oficial',
      text: `Parabéns pela ativação! O site oficial da {{empresa}} já está publicado e funcionando no endereço:\n\n{{subdominio}}\n\nAgora você já pode divulgar esse link no Instagram, WhatsApp e Google.`
    },
    {
      id: 'pos-02',
      title: '02. Envio do Link de Briefing',
      text: `Para personalizar os detalhes finais da sua página (horários de atendimento, textos específicos e links), preencha o formulário rápido de briefing no link abaixo:\n\n{{briefingUrl}}`
    },
    {
      id: 'pos-03',
      title: '03. Regra de Limite: 2 Alteracoes por Mes',
      text: `Para manter a qualidade e a agilidade de atendimento para todos os clientes, o seu plano mensal inclui até 2 solicitações de alteração por mês no subdomínio (como troca de fotos, textos, horários ou contatos).\n\nSempre que precisar ajustar algo, basta nos enviar por aqui.`
    },
    {
      id: 'pos-04',
      title: '04. O que esta incluso nas 2 alteracoes',
      text: `Dentro das suas 2 alterações mensais inclusas no plano, você pode solicitar:\n- Troca ou inclusão de fotos na galeria\n- Atualização de textos, serviços ou valores\n- Alteração de horário de funcionamento, endereço ou número de WhatsApp.`
    },
    {
      id: 'pos-05',
      title: '05. O que NAO esta incluso no plano basico',
      text: `Para alinharmos com total transparência: o plano mensal de R$ 29,90 cobre a hospedagem e até 2 alterações simples de conteúdo por mês.\n\nCriação de logotipos, gestão de redes sociais, sistemas de agendamento complexo ou páginas extras não fazem parte deste pacote.`
    },
    {
      id: 'pos-06',
      title: '06. Aviso de Limite Mensal Atingido (2/2)',
      text: `Verifiquei aqui que você já utilizou as 2 solicitações de alteração inclusas no seu ciclo deste mês.\n\nNovas atualizações de fotos ou textos poderão ser solicitadas normalmente a partir da virada do próximo mês.`
    },
    {
      id: 'pos-07',
      title: '07. Checklist para Pedir Alteracao em Lote',
      text: `Dica para aproveitar melhor sua franquia mensal: envie todas as mudanças que deseja fazer de uma única vez (ex: texto antigo, texto novo e fotos anexadas).\n\nAssim executamos tudo junto contando como apenas 1 alteração do mês.`
    },
    {
      id: 'pos-08',
      title: '08. Confirmacao de Alteracao Publicada',
      text: `As alterações solicitadas já foram aplicadas e publicadas no ar!\n\nAcesse seu link para conferir o resultado (caso não apareça de imediato, atualize a página ou abra em aba anônima):\n\n{{subdominio}}`
    },
    {
      id: 'pos-09',
      title: '09. Tutorial: Colocar site na Bio do Instagram',
      text: `Para ativar seu site no Instagram agora:\n1. Abra seu perfil e toque em "Editar perfil"\n2. Toque em "Links" ou "Site"\n3. Cole exatamente o endereço abaixo e salve:\n\n{{subdominio}}`
    },
    {
      id: 'pos-10',
      title: '10. Tutorial: Cadastrar no Google Meu Negocio',
      text: `Para aumentar suas visitas pelo Google Maps:\n1. Pesquise o nome da sua empresa logado na conta do Google\n2. Clique em "Editar perfil" > "Contato"\n3. No campo "Website", insira o seu link oficial:\n\n{{subdominio}}`
    },
    {
      id: 'pos-11',
      title: '11. Tutorial: Link no WhatsApp Business',
      text: `No seu WhatsApp Business, acesse Configurações > Ferramentas comerciais > Perfil comercial e adicione o seu site oficial no campo "Site":\n\n{{subdominio}}`
    },
    {
      id: 'pos-12',
      title: '12. Dica para Aumentar Avaliacoes no Google',
      text: `Sempre que finalizar um bom atendimento, envie seu link de avaliação do Google para o cliente.\n\nQuanto mais avaliações 5 estrelas você tiver, mais forte fica a credibilidade do seu negócio para quem visita seu site.`
    },
    {
      id: 'pos-13',
      title: '13. Aviso de Renovacao e Continuidade',
      text: `Sua assinatura mensal segue ativa e com hospedagem garantida, mantendo o site oficial da {{empresa}} disponível 24 horas por dia no Google.`
    },
    {
      id: 'pos-14',
      title: '14. Oferta de Upgrade para Dominio Proprio (R$ 490)',
      text: `Agora que seu site já está validado e rodando no ar, lembre-se de que quando quiser ter seu domínio próprio exclusivo (ex: suaempresa.com.br) sem mensalidade de plataforma, você pode fazer o upgrade para o Pacote Completo por R$ 490,00 (1 ano completo incluso, renovação de apenas R$ 70,00/ano e atualizações avulsas sob demanda por R$ 29,90).`
    },
    {
      id: 'pos-15',
      title: '15. Pedido de Indicacao de Parceiros',
      text: `Se você conhece outro empreendedor ou comércio da região que ainda não tem um site profissional no Google, pode indicar nosso contato. Teremos prazer em montar uma prévia gratuita para ele também.`
    },
    {
      id: 'pos-16',
      title: '16. Confirmacao de Comprovante Recebido',
      text: `Comprovante recebido com sucesso! Tudo certo com a sua assinatura e o seu site permanece ativo normalmente no ar.`
    },
    {
      id: 'pos-17',
      title: '17. Manutencao Preventiva e Velocidade',
      text: `Nossa equipe realizou uma rotina de otimização nos servidores para garantir que a sua página continue carregando rapidamente tanto no Wi-Fi quanto no 4G/5G dos seus clientes.`
    },
    {
      id: 'pos-18',
      title: '18. Prazo de Execucao das Alteracoes',
      text: `Recebemos o seu pedido de alteração dentro da franquia mensal. Nossa equipe executa e publica a atualização em até 48 horas úteis.`
    },
    {
      id: 'pos-19',
      title: '19. Acompanhamento de 30 Dias',
      text: `Olá, {{empresa}}! Completamos 30 dias com o seu site oficial no ar. Como está sendo o retorno dos clientes que chegam pelo link? Se precisar usar uma das suas 2 alterações mensais para atualizar algo, é só avisar.`
    },
    {
      id: 'pos-20',
      title: '20. Reativacao de Subdominio Concluida',
      text: `Pagamento confirmado e subdomínio reativado com sucesso! Sua página já está novamente acessível no endereço:\n\n{{subdominio}}`
    }
  ]
};

if (typeof window !== 'undefined') {
  window.QUICK_REPLIES = QUICK_REPLIES;
}
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { QUICK_REPLIES };
}
