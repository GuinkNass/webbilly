// ==============================================================================
// Billy Hunter — Service Worker de Background (Manifest V3)
// Gerencia requisições seguras para o Billy Desktop local (localhost:5200)
// ==============================================================================

const BILLY_SERVER = 'http://127.0.0.1:5200';
const BILLY_SERVER_FALLBACK = 'http://localhost:5200';

chrome.runtime.onInstalled.addListener(() => {
  console.log('[Billy Hunter] Extensão instalada e Service Worker ativo.');
});

// Helper de requisição resiliente com fallback automático entre 127.0.0.1 e localhost
async function resilientFetch(url, options = {}) {
  try {
    const res = await fetch(url, options);
    return res;
  } catch (primaryErr) {
    let fallbackUrl = null;
    if (url.includes('127.0.0.1:5200')) {
      fallbackUrl = url.replace('127.0.0.1:5200', 'localhost:5200');
    } else if (url.includes('localhost:5200')) {
      fallbackUrl = url.replace('localhost:5200', '127.0.0.1:5200');
    }
    if (fallbackUrl) {
      return await fetch(fallbackUrl, options);
    }
    throw primaryErr;
  }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // Proxy para contornar Mixed Content / PNA do Chrome com Fallback 127.0.0.1/localhost
  if (request.type === 'BILLY_FETCH') {
    const { url, options } = request;
    const controller = new AbortController();
    const timeoutMs = options && options.timeout ? options.timeout : 30000;
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

    const fetchOptions = {
      ...options,
      signal: controller.signal
    };

    resilientFetch(url, fetchOptions)
      .then(async (res) => {
        clearTimeout(timeoutId);
        let data = null;
        try {
          data = await res.json();
        } catch (e) {
          data = await res.text();
        }

        sendResponse({
          ok: res.ok,
          status: res.status,
          statusText: res.statusText,
          data
        });
      })
      .catch((err) => {
        clearTimeout(timeoutId);
        console.error('[Billy Background Error]:', err);
        sendResponse({
          ok: false,
          error: err.name === 'AbortError' 
            ? 'Tempo limite de resposta excedido.' 
            : (err.message || 'Falha ao conectar com o servidor do Billy.')
        });
      });

    return true; // Comunicação assíncrona
  }
});
