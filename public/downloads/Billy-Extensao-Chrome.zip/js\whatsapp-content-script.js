// ==============================================================================
// Billy Hunter — WhatsApp Web Header Bar (WA Web Plus Style)
// Barra Suspensa: Status Billy :5200 + Identificação de Website + 60 Respostas (Venda, SAC, Pós)
// Sem IA • Sem Auto-Envio • Foco Total em Produtividade Humana
// ==============================================================================

(function () {
  console.log('[Billy WhatsApp] Inicializando Barra Suspensa do WhatsApp Web...');

  const BILLY_SERVER = 'http://127.0.0.1:5200';
  const BILLY_SERVER_FALLBACK = 'http://localhost:5200';

  let isConnectedToBilly = false;
  let currentActivePhone = '';
  let currentActiveName = '';
  let currentActiveJid = '';

  let currentLeadInfo = {
    found: false,
    businessName: 'sua empresa',
    subdomain: 'suaempresa.webbilly.com.br',
    demoUrl: 'https://webbilly.com.br',
    proposalUrl: 'https://webbilly.com.br',
    briefingUrl: 'https://webbilly.com.br'
  };

  // Carrega respostas prontas do objeto global QUICK_REPLIES (injetado por quickReplies.js)
  function getQuickReplies() {
    if (typeof window.QUICK_REPLIES !== 'undefined' && window.QUICK_REPLIES) {
      return window.QUICK_REPLIES;
    }
    return { VENDA: [], SAC: [], POS: [] };
  }

  // ----------------------------------------------------------------------------
  // 1. INJEÇÃO DO SCRIPT NO MAIN WORLD (HOOK DE WEBPACK E DETECÇÃO DE CHAT)
  // ----------------------------------------------------------------------------
  function injectMainWorldScript() {
    try {
      const script = document.createElement('script');
      script.src = chrome.runtime.getURL('js/whatsapp-inject.js');
      script.onload = function () {
        this.remove();
      };
      (document.head || document.documentElement).appendChild(script);
    } catch (e) {
      console.warn('[Billy WhatsApp] Falha ao injetar script Main World:', e);
    }
  }

  // ----------------------------------------------------------------------------
  // 2. COMUNICAÇÃO RESILIENTE COM O BILLY DESKTOP (:5200)
  // ----------------------------------------------------------------------------
  async function callBilly(endpoint, body = null, method = 'GET') {
    const url = `${BILLY_SERVER}${endpoint}`;
    const options = {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined
    };

    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'BILLY_FETCH', url, options }, (response) => {
        if (chrome.runtime.lastError) {
          resolve({ ok: false, error: chrome.runtime.lastError.message });
        } else {
          resolve(response || { ok: false, error: 'Sem resposta' });
        }
      });
    });
  }

  // Checagem de integridade: checa http://localhost:5200/health
  async function checkServerHealth() {
    try {
      let res = await callBilly('/health', null, 'GET');
      if (!res || !res.ok) {
        res = await callBilly('/api/health', null, 'GET');
      }
      setConnectionStatus(Boolean(res && res.ok));
    } catch (e) {
      setConnectionStatus(false);
    }
  }

  function setConnectionStatus(isOnline) {
    isConnectedToBilly = isOnline;
    const dot = document.getElementById('billy-conn-dot');
    const text = document.getElementById('billy-conn-text');
    if (!dot || !text) return;

    if (isOnline) {
      dot.className = 'billy-status-dot online';
      text.innerText = 'Billy :5200 Online';
      text.style.color = '#10B981';
    } else {
      dot.className = 'billy-status-dot offline';
      text.innerText = 'Billy :5200 Offline';
      text.style.color = '#EF4444';
    }
  }

  // ----------------------------------------------------------------------------
  // 3. IDENTIFICAÇÃO DO WEBSITE PELO NÚMERO / CONTATO (/api/leads/lookup)
  // ----------------------------------------------------------------------------
  async function lookupLeadWebsite(phone, name) {
    const cleanPhone = (phone || '').replace(/\D/g, '');
    const cleanName = (name || '').trim();

    try {
      const q = new URLSearchParams();
      if (cleanPhone) q.append('phone', cleanPhone);
      if (cleanName) q.append('name', cleanName);

      const res = await callBilly(`/api/leads/lookup?${q.toString()}`, null, 'GET');
      if (res && res.ok && res.data) {
        const d = res.data;
        currentLeadInfo = {
          found: Boolean(d.found),
          businessName: d.businessName || cleanName || 'sua empresa',
          subdomain: d.subdomain || 'suaempresa.webbilly.com.br',
          demoUrl: d.demoUrl || 'https://webbilly.com.br',
          proposalUrl: d.proposalUrl || 'https://webbilly.com.br',
          briefingUrl: d.briefingUrl || 'https://webbilly.com.br'
        };
      } else {
        currentLeadInfo = {
          found: false,
          businessName: cleanName || 'sua empresa',
          subdomain: 'suaempresa.webbilly.com.br',
          demoUrl: 'https://webbilly.com.br',
          proposalUrl: 'https://webbilly.com.br',
          briefingUrl: 'https://webbilly.com.br'
        };
      }
    } catch (err) {
      currentLeadInfo = {
        found: false,
        businessName: cleanName || 'sua empresa',
        subdomain: 'suaempresa.webbilly.com.br',
        demoUrl: 'https://webbilly.com.br',
        proposalUrl: 'https://webbilly.com.br',
        briefingUrl: 'https://webbilly.com.br'
      };
    }

    updateWebsiteBadgeUI();
  }

  function updateWebsiteBadgeUI() {
    const badgeEl = document.getElementById('billy-subdomain-badge');
    const textEl = document.getElementById('billy-subdomain-text');
    if (!badgeEl || !textEl) return;

    if (currentLeadInfo.found && currentLeadInfo.subdomain) {
      textEl.innerText = currentLeadInfo.subdomain;
      textEl.style.color = '#60A5FA';
      badgeEl.style.borderColor = 'rgba(96, 165, 250, 0.45)';
      badgeEl.style.background = 'rgba(37, 99, 235, 0.15)';
      badgeEl.title = `Site Vinculado: ${currentLeadInfo.businessName} (${currentLeadInfo.demoUrl}) — Clique para abrir`;
      badgeEl.style.cursor = 'pointer';
      badgeEl.onclick = () => window.open(currentLeadInfo.demoUrl, '_blank');
    } else {
      textEl.innerText = 'Sem site vinculado';
      textEl.style.color = '#94A3B8';
      badgeEl.style.borderColor = 'rgba(255, 255, 255, 0.08)';
      badgeEl.style.background = 'rgba(30, 41, 59, 0.7)';
      badgeEl.title = 'Nenhum site vinculado a este contato no Billy Suite';
      badgeEl.style.cursor = 'default';
      badgeEl.onclick = null;
    }
  }

  // ----------------------------------------------------------------------------
  // 4. FORMATAÇÃO E INSERÇÃO DE RESPOSTAS PRONTAS NO CHAT
  // ----------------------------------------------------------------------------
  function formatReplyText(rawText) {
    const empresa = currentLeadInfo.businessName || 'sua empresa';
    const subdominio = currentLeadInfo.subdomain || 'suaempresa.webbilly.com.br';
    const demoUrl = currentLeadInfo.demoUrl || 'https://webbilly.com.br';
    const propostaUrl = currentLeadInfo.proposalUrl || 'https://webbilly.com.br';
    const briefingUrl = currentLeadInfo.briefingUrl || 'https://webbilly.com.br';

    let text = rawText
      .replace(/\{\{empresa\}\}/g, empresa)
      .replace(/\{\{subdominio\}\}/g, subdominio)
      .replace(/\{\{demoUrl\}\}/g, demoUrl)
      .replace(/\{\{propostaUrl\}\}/g, propostaUrl)
      .replace(/\{\{briefingUrl\}\}/g, briefingUrl);

    // Substituições adicionais de compatibilidade
    text = text
      .replace(/\{empresa\}/g, empresa)
      .replace(/\{nome\}/g, empresa)
      .replace(/\{subdominio\}/g, subdominio)
      .replace(/\{demoUrl\}/g, demoUrl)
      .replace(/\{propostaUrl\}/g, propostaUrl)
      .replace(/\{briefingUrl\}/g, briefingUrl);

    // REGRA DE OURO: Links sempre isolados por exatamente \n\n
    const urlRegex = /(https?:\/\/[^\s\n\r]+)/g;
    text = text.replace(urlRegex, (match) => {
      const clean = match.replace(/[.,;!?]+$/, '');
      return `\n\n${clean}\n\n`;
    });

    text = text.replace(/\n{3,}/g, '\n\n').trim();
    return text;
  }

  // Insere na caixa de texto do WhatsApp Web SEM ENVIAR (para o operador revisar e apertar Enter)
  async function insertIntoWhatsAppInput(text) {
    const input = document.querySelector('footer div[contenteditable="true"]') ||
                  document.querySelector('footer [role="textbox"]') ||
                  document.querySelector('div[contenteditable="true"][data-tab="10"]') ||
                  document.querySelector('div[role="textbox"]');

    if (!input) {
      try {
        await navigator.clipboard.writeText(text);
        showBillyToast('info', 'Texto copiado para a área de transferência! Cole com Ctrl+V.');
      } catch (e) {
        showBillyToast('error', 'Abra uma conversa no WhatsApp Web primeiro!');
      }
      return false;
    }

    input.focus();

    // Seleciona e limpa qualquer texto residual
    document.execCommand('selectAll', false, null);
    document.execCommand('delete', false, null);

    // Insere o texto preservando quebras de linha nativas
    document.execCommand('insertText', false, text);

    // Notifica o React do WhatsApp Web para habilitar o botão de envio
    input.dispatchEvent(new InputEvent('input', {
      bubbles: true,
      cancelable: true,
      data: text
    }));

    showBillyToast('success', 'Resposta rápida inserida! Revise e aperte Enter para enviar.');
    return true;
  }

  // ----------------------------------------------------------------------------
  // 5. RENDERIZAÇÃO DA BARRA SUPERIOR (5 ELEMENTOS ALINHADOS)
  // ----------------------------------------------------------------------------
  function injectTopBar() {
    if (document.getElementById('billy-wa-topbar')) return;

    // Injeta estilos CSS encapsulados
    const style = document.createElement('style');
    style.id = 'billy-wa-styles';
    style.textContent = `
      #billy-wa-topbar {
        position: fixed;
        top: 10px;
        right: 80px;
        z-index: 99999;
        display: flex;
        align-items: center;
        gap: 8px;
        background: rgba(15, 17, 26, 0.96);
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 12px;
        padding: 5px 8px;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.55), 0 0 10px rgba(99, 102, 241, 0.12);
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        font-size: 11.5px;
        color: #F4F4F5;
        user-select: none;
      }

      .billy-pill {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 5px 10px;
        border-radius: 8px;
        background: rgba(30, 41, 59, 0.7);
        border: 1px solid rgba(255, 255, 255, 0.08);
        font-weight: 600;
        transition: all 0.15s ease;
      }

      .billy-status-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        display: inline-block;
      }
      .billy-status-dot.online {
        background: #10B981;
        box-shadow: 0 0 8px #10B981;
      }
      .billy-status-dot.offline {
        background: #EF4444;
        box-shadow: 0 0 8px #EF4444;
      }

      /* Dropdowns */
      .billy-dropdown-wrap {
        position: relative;
      }

      .billy-dropdown-btn {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        background: #1E293B;
        color: #F1F5F9;
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 8px;
        padding: 5px 12px;
        font-size: 11.5px;
        font-weight: 700;
        cursor: pointer;
        transition: all 0.15s ease;
        letter-spacing: 0.3px;
      }
      .billy-dropdown-btn:hover {
        background: #334155;
        border-color: rgba(99, 102, 241, 0.5);
        color: #FFFFFF;
      }
      .billy-dropdown-btn.active {
        background: #312E81;
        border-color: #6366F1;
        color: #E0E7FF;
      }
      .billy-dropdown-btn .billy-caret {
        font-size: 8px;
        opacity: 0.7;
        transition: transform 0.15s ease;
      }
      .billy-dropdown-btn.active .billy-caret {
        transform: rotate(180deg);
      }

      .billy-dropdown-menu {
        position: absolute;
        top: calc(100% + 6px);
        right: 0;
        width: 360px;
        background: #111420;
        border: 1px solid rgba(99, 102, 241, 0.35);
        border-radius: 12px;
        padding: 8px;
        box-shadow: 0 16px 36px rgba(0, 0, 0, 0.75);
        display: none;
        flex-direction: column;
        gap: 6px;
        z-index: 100000;
        animation: billyFadeIn 0.15s ease;
      }
      @keyframes billyFadeIn {
        from { opacity: 0; transform: translateY(-4px); }
        to { opacity: 1; transform: translateY(0); }
      }

      .billy-search-box {
        padding: 2px 2px 6px 2px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.08);
      }
      .billy-search-input {
        width: 100%;
        box-sizing: border-box;
        background: #0B0D14;
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 7px;
        padding: 6px 10px;
        color: #FFFFFF;
        font-size: 11px;
        outline: none;
      }
      .billy-search-input:focus {
        border-color: #6366F1;
      }

      .billy-items-list {
        max-height: 360px;
        overflow-y: auto;
        display: flex;
        flex-direction: column;
        gap: 4px;
        padding-right: 4px;
      }
      .billy-items-list::-webkit-scrollbar {
        width: 5px;
      }
      .billy-items-list::-webkit-scrollbar-thumb {
        background: #27272A;
        border-radius: 4px;
      }

      .billy-reply-item {
        padding: 7px 10px;
        border-radius: 7px;
        background: #181B28;
        border: 1px solid transparent;
        cursor: pointer;
        transition: all 0.15s ease;
        text-align: left;
        display: flex;
        flex-direction: column;
        gap: 2px;
      }
      .billy-reply-item:hover {
        background: #23283D;
        border-color: rgba(99, 102, 241, 0.5);
      }
      .billy-reply-title {
        font-size: 11px;
        font-weight: 700;
        color: #F1F5F9;
      }
      .billy-reply-preview {
        font-size: 10px;
        color: #94A3B8;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      /* Toast */
      .billy-wa-toast {
        position: fixed;
        bottom: 24px;
        right: 24px;
        z-index: 100002;
        background: #181B28;
        color: #F4F4F5;
        border: 1px solid rgba(99, 102, 241, 0.5);
        padding: 10px 16px;
        border-radius: 10px;
        font-size: 12px;
        font-weight: 600;
        box-shadow: 0 10px 30px rgba(0,0,0,0.6);
        display: flex;
        align-items: center;
        gap: 8px;
        animation: billySlideUp 0.25s ease;
      }
      @keyframes billySlideUp {
        from { transform: translateY(15px); opacity: 0; }
        to { transform: translateY(0); opacity: 1; }
      }
    `;
    document.head.appendChild(style);

    // Cria os 5 elementos
    const bar = document.createElement('div');
    bar.id = 'billy-wa-topbar';
    bar.innerHTML = `
      <!-- 1. Status de Conexão -->
      <div class="billy-pill" id="billy-connection-pill" title="Clique para verificar conexão com Billy Desktop (:5200)" style="cursor:pointer;">
        <span class="billy-status-dot offline" id="billy-conn-dot"></span>
        <span id="billy-conn-text" style="color: #94A3B8;">Billy :5200 Offline</span>
      </div>

      <!-- 2. Badge de Identificação do Website -->
      <div class="billy-pill" id="billy-subdomain-badge" style="max-width: 280px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
        <span>🌐</span>
        <span id="billy-subdomain-text" style="color: #94A3B8;">Sem site vinculado</span>
      </div>

      <!-- 3. Dropdown VENDA (20 Respostas) -->
      <div class="billy-dropdown-wrap" id="billy-wrap-venda">
        <button class="billy-dropdown-btn" id="billy-btn-venda" title="20 Respostas Prontas de Venda">
          <span>VENDA</span>
          <span class="billy-caret">▼</span>
        </button>
        <div class="billy-dropdown-menu" id="billy-menu-venda">
          <div class="billy-search-box">
            <input type="text" class="billy-search-input" id="billy-search-venda" placeholder="🔍 Filtrar 20 respostas de Venda..." />
          </div>
          <div class="billy-items-list" id="billy-list-venda"></div>
        </div>
      </div>

      <!-- 4. Dropdown SAC (20 Respostas) -->
      <div class="billy-dropdown-wrap" id="billy-wrap-sac">
        <button class="billy-dropdown-btn" id="billy-btn-sac" title="20 Respostas Prontas de SAC">
          <span>SAC</span>
          <span class="billy-caret">▼</span>
        </button>
        <div class="billy-dropdown-menu" id="billy-menu-sac">
          <div class="billy-search-box">
            <input type="text" class="billy-search-input" id="billy-search-sac" placeholder="🔍 Filtrar 20 respostas de SAC..." />
          </div>
          <div class="billy-items-list" id="billy-list-sac"></div>
        </div>
      </div>

      <!-- 5. Dropdown PÓS (20 Respostas) -->
      <div class="billy-dropdown-wrap" id="billy-wrap-pos">
        <button class="billy-dropdown-btn" id="billy-btn-pos" title="20 Respostas Prontas de Pós-Venda">
          <span>PÓS</span>
          <span class="billy-caret">▼</span>
        </button>
        <div class="billy-dropdown-menu" id="billy-menu-pos">
          <div class="billy-search-box">
            <input type="text" class="billy-search-input" id="billy-search-pos" placeholder="🔍 Filtrar 20 respostas de Pós..." />
          </div>
          <div class="billy-items-list" id="billy-list-pos"></div>
        </div>
      </div>
    `;

    document.body.appendChild(bar);

    // Eventos
    document.getElementById('billy-connection-pill').addEventListener('click', checkServerHealth);

    setupDropdown('venda', 'VENDA');
    setupDropdown('sac', 'SAC');
    setupDropdown('pos', 'POS');

    // Fecha qualquer dropdown aberto ao clicar fora
    document.addEventListener('click', (e) => {
      ['venda', 'sac', 'pos'].forEach(cat => {
        const wrap = document.getElementById(`billy-wrap-${cat}`);
        const menu = document.getElementById(`billy-menu-${cat}`);
        const btn = document.getElementById(`billy-btn-${cat}`);
        if (wrap && menu && !wrap.contains(e.target)) {
          menu.style.display = 'none';
          btn?.classList.remove('active');
        }
      });
    });
  }

  function setupDropdown(categoryKey, dataCategory) {
    const btn = document.getElementById(`billy-btn-${categoryKey}`);
    const menu = document.getElementById(`billy-menu-${categoryKey}`);
    const searchInput = document.getElementById(`billy-search-${categoryKey}`);
    const listEl = document.getElementById(`billy-list-${categoryKey}`);
    if (!btn || !menu || !listEl) return;

    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const isVisible = menu.style.display === 'flex';

      // Fecha todos os outros primeiro
      ['venda', 'sac', 'pos'].forEach(c => {
        const m = document.getElementById(`billy-menu-${c}`);
        const b = document.getElementById(`billy-btn-${c}`);
        if (m) m.style.display = 'none';
        if (b) b.classList.remove('active');
      });

      if (!isVisible) {
        menu.style.display = 'flex';
        btn.classList.add('active');
        renderDropdownItems(dataCategory, listEl, searchInput?.value || '');
        if (searchInput) searchInput.focus();
      }
    });

    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        renderDropdownItems(dataCategory, listEl, e.target.value);
      });
      searchInput.addEventListener('click', (e) => e.stopPropagation());
    }
  }

  function renderDropdownItems(dataCategory, listEl, filterText) {
    const all = getQuickReplies();
    const items = all[dataCategory] || [];
    const q = (filterText || '').toLowerCase().trim();

    const filtered = items.filter(it => {
      if (!q) return true;
      return (it.title || '').toLowerCase().includes(q) || (it.text || '').toLowerCase().includes(q);
    });

    if (filtered.length === 0) {
      listEl.innerHTML = `<div style="padding:12px;text-align:center;color:#71717A;font-size:11px;">Nenhuma resposta encontrada.</div>`;
      return;
    }

    listEl.innerHTML = filtered.map(item => `
      <div class="billy-reply-item" data-id="${item.id}" title="Clique para inserir no chat">
        <span class="billy-reply-title">${item.title}</span>
        <span class="billy-reply-preview">${item.text.replace(/\n+/g, ' ').slice(0, 80)}...</span>
      </div>
    `).join('');

    listEl.querySelectorAll('.billy-reply-item').forEach(el => {
      el.addEventListener('click', async (e) => {
        e.stopPropagation();
        const itemId = el.getAttribute('data-id');
        const selected = items.find(it => it.id === itemId);

        // Fecha todos os menus
        ['venda', 'sac', 'pos'].forEach(c => {
          const m = document.getElementById(`billy-menu-${c}`);
          const b = document.getElementById(`billy-btn-${c}`);
          if (m) m.style.display = 'none';
          if (b) b.classList.remove('active');
        });

        if (selected) {
          const formatted = formatReplyText(selected.text);
          await insertIntoWhatsAppInput(formatted);
        }
      });
    });
  }

  // ----------------------------------------------------------------------------
  // 6. OBSERVAÇÃO DE TROCA DE CHAT NO WHATSAPP WEB
  // ----------------------------------------------------------------------------
  let lastInspectedChatKey = '';

  function inspectActiveChatFromDOM() {
    try {
      const header = document.querySelector('#main header');
      if (!header) return;

      const titleEl = header.querySelector('span[title], span[dir="auto"], div[role="button"] span');
      const headerName = titleEl ? (titleEl.getAttribute('title') || titleEl.innerText || '').trim() : '';

      let phone = '';
      const phoneMatch = headerName.match(/\+?\d[\d\s-]{7,}\d/);
      if (phoneMatch) {
        phone = phoneMatch[0].replace(/\D/g, '');
      }

      if (!phone) {
        const msgNodes = document.querySelectorAll('#main div[data-id], #main [data-id*="@c.us"], #main [data-id*="@s.whatsapp.net"]');
        for (const node of msgNodes) {
          const mId = node.getAttribute('data-id') || '';
          const match = mId.match(/(?:true|false)_(\d{10,15})@(c\.us|s\.whatsapp\.net)/);
          if (match) {
            phone = match[1];
            break;
          }
        }
      }

      const chatKey = `${phone}_${headerName}`;
      if (chatKey !== lastInspectedChatKey && (phone || headerName)) {
        lastInspectedChatKey = chatKey;
        currentActivePhone = phone;
        currentActiveName = headerName;
        console.log(`[Billy WhatsApp] Chat ativo detectado: "${headerName}" (${phone})`);
        lookupLeadWebsite(phone, headerName);
      }
    } catch (e) {}
  }

  // Listener para eventos do Main World (whatsapp-inject.js)
  window.addEventListener('message', (event) => {
    if (!event.data) return;

    if (event.data.type === 'BILLY_ACTIVE_CHAT_CHANGED') {
      const { phone, name, jid } = event.data;
      currentActivePhone = phone || '';
      currentActiveName = name || '';
      currentActiveJid = jid || '';
      lastInspectedChatKey = `${phone}_${name}`;
      lookupLeadWebsite(phone, name);
    }
  });

  // Toast feedback
  function showBillyToast(type, message) {
    const existing = document.querySelector('.billy-wa-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = 'billy-wa-toast';
    const icon = type === 'success' ? '✅' : (type === 'error' ? '❌' : 'ℹ️');
    toast.innerHTML = `<span>${icon}</span><span>${message}</span>`;
    document.body.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transition = 'opacity 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3800);
  }

  // ----------------------------------------------------------------------------
  // 7. BOOTSTRAP
  // ----------------------------------------------------------------------------
  injectMainWorldScript();

  function boot() {
    injectTopBar();
    checkServerHealth();

    // Polling regular de conexão
    setInterval(checkServerHealth, 6000);

    // Polling regular de detecção de troca de chat
    setInterval(inspectActiveChatFromDOM, 1200);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => setTimeout(boot, 2000));
  } else {
    setTimeout(boot, 2000);
  }
})();
