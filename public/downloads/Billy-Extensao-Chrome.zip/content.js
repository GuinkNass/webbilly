// Billy Hunter — Content Script para Google Maps (v2.1)
(function () {
  const BILLY_SERVER = 'http://127.0.0.1:5200';
  let isScanning = false;

  /**
   * Envia requisição ao Billy Desktop de forma segura via Background Service Worker
   * para contornar restrições de Mixed Content e Private Network Access.
   */
  async function callBillyServer(endpoint, body = null, method = 'POST') {
    const url = `${BILLY_SERVER}${endpoint}`;
    const options = {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined
    };

    // 1. Tenta delegar para o background service worker (imune a Mixed Content HTTPS -> HTTP)
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
      try {
        const resp = await new Promise((resolve) => {
          chrome.runtime.sendMessage({ type: 'BILLY_FETCH', url, options }, (response) => {
            if (chrome.runtime.lastError) {
              resolve({ ok: false, error: chrome.runtime.lastError.message });
            } else {
              resolve(response || { ok: false, error: 'Sem resposta do service worker' });
            }
          });
        });

        if (resp && resp.ok) {
          return resp.data;
        }
        if (resp && resp.error) {
          throw new Error(resp.error);
        }
      } catch (workerErr) {
        console.warn('[Billy Extension] Background request failed, trying direct fetch:', workerErr);
      }
    }

    // 2. Fallback direto
    const response = await fetch(url, options);
    if (!response.ok) {
      const errData = await response.json().catch(() => ({}));
      throw new Error(errData.error || `Servidor respondeu com status ${response.status}`);
    }
    return await response.json();
  }

  function getActiveMapsQuery() {
    const searchInput = document.querySelector('input#searchboxinput, input[aria-label*="Pesquisar"], input[name="q"]');
    if (searchInput && searchInput.value && searchInput.value.trim()) {
      return searchInput.value.trim();
    }
    const url = window.location.href;
    const match = url.match(/\/maps\/search\/([^/@?]+)/);
    if (match && match[1]) {
      return decodeURIComponent(match[1].replace(/\+/g, ' '));
    }
    return '';
  }

  async function handleGosomScanClick() {
    if (isScanning) return;

    let query = getActiveMapsQuery();
    if (!query) {
      query = prompt('Informe a pesquisa a varrer (ex: restaurantes, barbearias em pinheiros):');
      if (!query || !query.trim()) return;
      query = query.trim();
    }

    const btn = document.getElementById('billy-hunter-btn');
    const origHtml = btn.innerHTML;
    isScanning = true;
    btn.disabled = true;
    btn.innerHTML = `
      <span class="billy-spinner"></span>
      <span>Minerando no Billy com Gosom...</span>
    `;

    showToast('info', `🚀 Varrendo "${query}" com Gosom Engine... Extraindo fotos reais, telefones e reviews.`);

    try {
      const data = await callBillyServer('/api/scraper/google-maps', { query, depth: 1 });
      const totalImported = data.imported ?? data.count ?? 0;
      showToast('success', `✅ Varredura concluída! ${totalImported} estabelecimentos enviados para o Billy!`);

      btn.innerHTML = `
        <span style="color: #34d399; font-size: 16px;">✅</span>
        <span>${totalImported} Leads Enviados ao Billy!</span>
      `;

      setTimeout(() => {
        btn.innerHTML = origHtml;
        btn.disabled = false;
        isScanning = false;
      }, 4500);
    } catch (err) {
      console.error('[Billy Hunter Gosom Error]:', err);
      showToast('error', `⚠️ Falha ao minerar: ${err.message}. Certifique-se de que o aplicativo Billy Desktop está aberto.`);
      btn.innerHTML = origHtml;
      btn.disabled = false;
      isScanning = false;
    }
  }

  function initBillyHunter() {
    if (document.getElementById('billy-hunter-floating-container')) return;

    const container = document.createElement('div');
    container.id = 'billy-hunter-floating-container';

    // Único Botão Gosom: faz a varredura completa e envia direto ao Billy
    const btn = document.createElement('button');
    btn.id = 'billy-hunter-btn';
    btn.title = 'Executar varredura automática com motor Gosom e enviar para o Billy Desktop';
    const logoUrl = chrome.runtime.getURL('icons/icon-48.png');
    btn.innerHTML = `
      <img src="${logoUrl}" class="billy-icon-img" style="width: 20px; height: 20px; border-radius: 6px; object-fit: contain; vertical-align: middle;" alt="Billy" />
      <span>⚡ Varrer Leads com Gosom</span>
    `;
    btn.addEventListener('click', handleGosomScanClick);
    container.appendChild(btn);

    document.body.appendChild(container);
  }

  function getVisibleElements() {
    const items = document.querySelectorAll('div.Nv2PK, div[role="article"], div.m6QErb div[jsaction*="mouseover"], a.hfpxzc');
    const cards = [];
    const seen = new Set();

    for (const el of items) {
      const container = el.closest('div.Nv2PK') || el.closest('div[role="article"]') || el;
      if (!seen.has(container)) {
        seen.add(container);
        cards.push(container);
      }
    }
    return cards;
  }

  function updateCounter() {
    const counterEl = document.getElementById('billy-hunter-count');
    if (!counterEl) return;
    const cards = getVisibleElements();
    counterEl.innerText = `${cards.length}`;
  }

  async function handleScanClick() {
    if (isScanning) return;
    isScanning = true;

    const btn = document.getElementById('billy-hunter-btn');
    const originalText = btn.innerHTML;
    btn.innerHTML = `
      <span class="billy-icon">⏳</span>
      <span>Capturando dados do Maps...</span>
    `;

    try {
      showToast('info', 'Analisando estabelecimentos, contatos e fotos no Google Maps...');
      const leads = await extractLeadsFromMaps();

      if (leads.length === 0) {
        showToast('error', 'Nenhum lead encontrado na visualização atual. Pesquise por uma categoria (ex: "tatuador sp", "odontologia") e role a lista.');
        return;
      }

      showToast('info', `Enviando ${leads.length} leads para o Billy Desktop na porta 5200...`);
      const resData = await callBillyServer('/api/leads/import', { leads });
      const totalPhotos = leads.reduce((acc, l) => acc + (Array.isArray(l.photos) ? l.photos.length : (l.thumbnailUrl ? 1 : 0)), 0);
      const photoMsg = totalPhotos > 0 ? ` com ${totalPhotos} fotos reais capturadas!` : '!';
      showToast('success', `✅ ${resData.imported || leads.length} Oportunidade(s) enviada(s) para o Billy${photoMsg}`);
    } catch (err) {
      console.error('[Billy Hunter Error]:', err);
      showToast('error', '⚠️ Billy Desktop não detectado na porta 5200. Verifique se o aplicativo Billy está aberto no Windows.');
    } finally {
      isScanning = false;
      btn.innerHTML = originalText;
      updateCounter();
    }
  }

  function upgradeGoogleImageUrl(url) {
    if (!url) return '';
    try {
      if (url.includes('googleusercontent.com') || url.includes('ggpht.com')) {
        // Substitui restrições de tamanho (ex: =w92-h92-k-no ou =s90 ou =w114-k-no) por alta resolução 1200x900
        return url.replace(/=w\d+(-h\d+)?(-k-no)?.*$/, '=w1200-h900-k-no')
                  .replace(/=s\d+.*$/, '=s1200');
      }
    } catch (e) {}
    return url;
  }

  function isValidPlacePhoto(url) {
    if (!url) return false;
    const lower = url.toLowerCase();
    if (
      lower.includes('avatar') || 
      lower.includes('profile') || 
      lower.includes('default_user') || 
      lower.includes('photo.jpg') || 
      lower.includes('marker') || 
      lower.includes('icon') || 
      lower.includes('arrow') || 
      lower.includes('navigation') || 
      lower.includes('gstatic.com') || 
      lower.includes('=s32') || 
      lower.includes('=s48') || 
      lower.includes('=s64') ||
      lower.includes('=w36-') ||
      lower.includes('=w48-')
    ) {
      return false;
    }
    return lower.includes('googleusercontent.com') || lower.includes('ggpht.com');
  }

  function extractPhotosFromContainer(container = document, maxPhotos = 25) {
    const photosSet = new Set();

    // 1. Tags <img> do container
    const imgs = container.querySelectorAll('img[src*="googleusercontent.com"], img[src*="ggpht.com"]');
    imgs.forEach(img => {
      const src = img.src || img.getAttribute('src');
      if (src && isValidPlacePhoto(src)) {
        photosSet.add(upgradeGoogleImageUrl(src));
      }
    });

    // 2. Elementos com background-image no style (comum no grid de fotos e tiles do Maps)
    const bgElements = container.querySelectorAll('div[style*="googleusercontent.com"], div[style*="ggpht.com"], button[style*="googleusercontent.com"], a[style*="googleusercontent.com"]');
    bgElements.forEach(el => {
      const style = el.getAttribute('style') || '';
      const match = style.match(/url\(["']?(https:\/\/[^"')]+(?:googleusercontent|ggpht)\.com\/[^"')]+)["']?\)/i);
      if (match && match[1] && isValidPlacePhoto(match[1])) {
        photosSet.add(upgradeGoogleImageUrl(match[1]));
      }
    });

    return Array.from(photosSet).slice(0, maxPhotos);
  }

  async function extractLeadsFromMaps() {
    const cards = getVisibleElements();
    const leads = [];
    const seenTitles = new Set();

    for (const card of cards) {
      try {
        // 1. Título do estabelecimento
        let title = '';
        const titleEl = card.querySelector('div.qBF1Pd, div.fontHeadlineSmall, a.hfpxzc, h2, h3');
        if (titleEl) {
          title = titleEl.innerText || titleEl.getAttribute('aria-label') || '';
        }
        title = title.trim();
        if (!title || seenTitles.has(title.toLowerCase())) continue;
        seenTitles.add(title.toLowerCase());

        // 2. Link do Maps
        const linkEl = card.querySelector('a.hfpxzc') || card.querySelector('a[href*="/maps/place/"]');
        const mapsUrl = linkEl ? linkEl.href : window.location.href;

        // 3. Avaliação e contagem de reviews
        let rating = null;
        let reviewCount = 0;
        const ratingEl = card.querySelector('span.MW4etd');
        if (ratingEl) {
          const rText = ratingEl.innerText.replace(',', '.').trim();
          rating = parseFloat(rText) || null;
        }

        const reviewEl = card.querySelector('span.UY7F9, span[aria-label*="avaliações"]');
        if (reviewEl) {
          const revMatch = reviewEl.innerText.match(/[\d.,]+/);
          if (revMatch) {
            reviewCount = parseInt(revMatch[0].replace(/\D/g, ''), 10) || 0;
          }
        }

        // 4. Categoria e Endereço
        let category = 'Comércio Local';
        let address = '';
        const lineContainers = card.querySelectorAll('div.W4Efsd');

        if (lineContainers.length > 0) {
          const fullText = Array.from(lineContainers).map(el => el.innerText).join(' • ');
          const parts = fullText.split('·').map(p => p.trim());

          if (parts.length > 0 && parts[0]) {
            category = parts[0].replace(/[R$]+/g, '').replace(/[\d.,]+/g, '').trim() || category;
          }

          if (parts.length > 1) {
            address = parts[1].replace(/Aberto|Fechado.*/i, '').trim();
          } else if (lineContainers[1]) {
            address = lineContainers[1].innerText.replace(/Aberto|Fechado.*/i, '').trim();
          }
        }

        // 5. Fotos do Estabelecimento no Card
        const cardPhotos = extractPhotosFromContainer(card, 6);
        const thumbnailUrl = cardPhotos[0] || '';

        // 6. Telefone (Seletores aprimorados + Regex BR)
        let phone = '';
        const phoneButton = card.querySelector('button[data-item-id^="phone:"], [data-item-id*="phone"], button[data-tooltip*="telefone" i], a[data-tooltip*="telefone" i], button[aria-label*="telefone" i]');
        if (phoneButton) {
          const dataId = phoneButton.getAttribute('data-item-id') || '';
          if (dataId.includes('phone:tel:')) {
            phone = dataId.replace('phone:tel:', '').replace(/\D/g, '');
          } else {
            phone = (phoneButton.innerText || phoneButton.getAttribute('aria-label') || '').replace(/\D/g, '');
          }
        }

        // Se não achou em botão específico, faz regex ampla no card
        if (!phone) {
          const cardAllText = (card.innerText || '') + ' ' + (card.innerHTML || '');
          const phoneRegex = /(?:\+?55\s?)?(?:\(?([1-9]{2})\)?\s?)?(?:9\s?)?(\d{4})[-.\s]?(\d{4})/g;
          const match = phoneRegex.exec(cardAllText);
          if (match) {
            const ddd = match[1] || '11';
            const part1 = match[2];
            const part2 = match[3];
            phone = `55${ddd}${part1}${part2}`;
          }
        }

        if (phone && !phone.startsWith('55')) {
          phone = `55${phone}`;
        }

        // 7. Website e Instagram
        let websiteUrl = '';
        let instagramUrl = '';
        let instagramUsername = '';

        const authorityLink = card.querySelector('a[data-item-id="authority"], a[data-tooltip*="site" i], a[data-tooltip*="website" i], a[aria-label*="site" i]');
        if (authorityLink && authorityLink.href) {
          websiteUrl = authorityLink.href;
        }

        const allLinks = card.querySelectorAll('a');
        for (const a of allLinks) {
          const h = a.href || '';
          if (h.includes('instagram.com/')) {
            instagramUrl = h;
            const uMatch = h.match(/instagram\.com\/([a-zA-Z0-9_\.]+)/);
            if (uMatch && !['p', 'reel', 'explore', 'stories'].includes(uMatch[1])) {
              instagramUsername = uMatch[1];
            }
          } else if (h.startsWith('http') && !h.includes('google.com') && !websiteUrl) {
            websiteUrl = h;
          }
        }

        if (websiteUrl && websiteUrl.includes('instagram.com/')) {
          instagramUrl = websiteUrl;
          const uMatch = websiteUrl.match(/instagram\.com\/([a-zA-Z0-9_\.]+)/);
          if (uMatch && !['p', 'reel', 'explore'].includes(uMatch[1])) {
            instagramUsername = uMatch[1];
          }
          websiteUrl = '';
        }

        // Limpa URL do site se for redirecionamento do Google
        if (websiteUrl && websiteUrl.includes('/url?q=')) {
          try {
            const urlObj = new URL(websiteUrl);
            const clean = urlObj.searchParams.get('q');
            if (clean) websiteUrl = clean;
          } catch (e) {}
        }

        // 8. Horários de Funcionamento (Cards do Maps)
        let openingHours = '';
        const hourSpans = card.querySelectorAll('span, div.W4Efsd span');
        for (const el of hourSpans) {
          const txt = (el.innerText || '').trim();
          if (/(?:Aberto|Fechado|Fecha às|Abre às|24 horas|Aberto 24h)/i.test(txt) && txt.length < 60) {
            openingHours = txt;
            break;
          }
        }

        // 9. Coordenadas e Embed do Google Maps para sincronia na Landing Page
        let coordinates = null;
        const coordMatch = mapsUrl.match(/@(-?\d+\.\d+),(-?\d+\.\d+)/) || window.location.href.match(/@(-?\d+\.\d+),(-?\d+\.\d+)/);
        if (coordMatch) {
          coordinates = { lat: parseFloat(coordMatch[1]), lng: parseFloat(coordMatch[2]) };
        }
        const queryMap = coordinates ? `${coordinates.lat},${coordinates.lng}` : `${title}, ${address}`;
        const mapEmbedUrl = `https://maps.google.com/maps?q=${encodeURIComponent(queryMap)}&t=&z=15&ie=UTF8&iwloc=&output=embed`;

        // 10. Comentários Positivos Reais do Google (Snippets no Card)
        const reviews = [];
        const reviewSnippetEl = card.querySelector('div.ah5Ghc, div[jsinstance] span, div.fontBodySmall span');
        if (reviewSnippetEl) {
          const rText = reviewSnippetEl.innerText.replace(/^[“"\s]+|[”"\s]+$/g, '').trim();
          if (rText && rText.length > 8) {
            reviews.push({
              author: 'Cliente no Google Maps',
              rating: 5,
              text: rText,
              date: 'Avaliação recomendada'
            });
          }
        }

        leads.push({
          title,
          category,
          address,
          phone,
          websiteUrl,
          instagramUrl,
          instagram: instagramUsername,
          thumbnailUrl,
          photos: cardPhotos,
          rating,
          reviewCount,
          mapsUrl,
          openingHours,
          mapEmbedUrl,
          coordinates,
          reviews
        });

      } catch (errCard) {
        console.warn('[Billy Hunter] Erro ao extrair card individual:', errCard);
      }
    }

    if (leads.length === 0) {
      const singleLead = extractSingleActivePlace();
      if (singleLead) leads.push(singleLead);
    }

    return leads;
  }

  function extractSingleActivePlace() {
    const titleEl = document.querySelector('h1.DUwDvf');
    if (!titleEl) return null;

    const title = titleEl.innerText.trim();
    const categoryEl = document.querySelector('button.DkEaL');
    const category = categoryEl ? categoryEl.innerText.trim() : 'Geral';

    let address = '';
    const addressEl = document.querySelector('button[data-item-id="address"] .Io6YTe, button[data-item-id="address"]');
    if (addressEl) address = addressEl.innerText.trim();

    let phone = '';
    const phoneEl = document.querySelector('button[data-item-id*="phone"] .Io6YTe, button[data-item-id*="phone"]');
    if (phoneEl) {
      const raw = (phoneEl.getAttribute('data-item-id') || phoneEl.innerText).replace(/\D/g, '');
      phone = raw.startsWith('55') ? raw : `55${raw}`;
    }

    // 5. Galeria Completa de Fotos do Estabelecimento (aba Fotos ou Página Ativa)
    const placePhotos = extractPhotosFromContainer(document, 30);
    const mainImg = document.querySelector('button[jsaction*="heroHeaderImage"] img, img.k3OBKc, div[jsaction*="pane.heroHeaderImage"] img, div[role="main"] img[src*="googleusercontent.com"]');
    if (mainImg && isValidPlacePhoto(mainImg.src)) {
      const upgradedMain = upgradeGoogleImageUrl(mainImg.src);
      if (!placePhotos.includes(upgradedMain)) {
        placePhotos.unshift(upgradedMain);
      }
    }
    const thumbnailUrl = placePhotos[0] || '';

    let websiteUrl = '';
    let instagram = '';
    let instagramUrl = '';
    const webEl = document.querySelector('a[data-item-id="authority"], a[data-tooltip*="site" i]');
    if (webEl) {
      let href = webEl.href;
      if (href.includes('/url?q=')) {
        try {
          const urlObj = new URL(href);
          const clean = urlObj.searchParams.get('q');
          if (clean) href = clean;
        } catch (e) {}
      }
      if (href.includes('instagram.com/')) {
        instagramUrl = href;
        const uMatch = href.match(/instagram\.com\/([a-zA-Z0-9_\.]+)/);
        if (uMatch) instagram = uMatch[1];
      } else {
        websiteUrl = href;
      }
    }

    let rating = null;
    const ratingEl = document.querySelector('div.F7nice span[aria-hidden="true"]');
    if (ratingEl) {
      rating = parseFloat(ratingEl.innerText.replace(',', '.')) || null;
    }

    let reviewCount = 0;
    const revCountEl = document.querySelector('div.F7nice span[aria-label*="avaliações"]');
    if (revCountEl) {
      const match = (revCountEl.innerText || revCountEl.getAttribute('aria-label') || '').match(/[\d.,]+/);
      if (match) reviewCount = parseInt(match[0].replace(/\D/g, ''), 10) || 0;
    }

    // Horários detalhados no painel ativo
    let openingHours = '';
    const hoursTableRows = document.querySelectorAll('table.eKjhbv tr, div.t392fc tr, div[data-item-id*="oh:"]');
    if (hoursTableRows && hoursTableRows.length > 0) {
      const hoursList = [];
      hoursTableRows.forEach(row => {
        const text = row.innerText ? row.innerText.replace(/\n+/g, ': ').trim() : '';
        if (text) hoursList.push(text);
      });
      if (hoursList.length > 0) {
        openingHours = hoursList.join(' • ');
      }
    }
    if (!openingHours) {
      const hoursBtn = document.querySelector('button[data-item-id="oh"] .Io6YTe, div[data-item-id="oh"]');
      if (hoursBtn) openingHours = hoursBtn.innerText.trim();
    }

    // Coordenadas e Embed do Google Maps
    let coordinates = null;
    const coordMatch = window.location.href.match(/@(-?\d+\.\d+),(-?\d+\.\d+)/);
    if (coordMatch) {
      coordinates = { lat: parseFloat(coordMatch[1]), lng: parseFloat(coordMatch[2]) };
    }
    const queryMap = coordinates ? `${coordinates.lat},${coordinates.lng}` : `${title}, ${address}`;
    const mapEmbedUrl = `https://maps.google.com/maps?q=${encodeURIComponent(queryMap)}&t=&z=15&ie=UTF8&iwloc=&output=embed`;

    // Comentários Positivos Reais do Google Maps
    const reviews = [];
    const reviewCards = document.querySelectorAll('div.jftiEf, div[data-review-id], div.G54Mfd');
    reviewCards.forEach(card => {
      if (reviews.length >= 6) return;
      const authorEl = card.querySelector('div.d4r55, button.al6Kxe, .WNxFaf');
      const textEl = card.querySelector('span.wiI7pd, div.MyEned');
      const starEl = card.querySelector('span.kvMYJc');
      const dateEl = card.querySelector('span.rsqaWe');

      const author = authorEl ? authorEl.innerText.trim() : 'Cliente Google';
      const text = textEl ? textEl.innerText.trim() : '';
      let rRating = 5;
      if (starEl) {
        const aria = starEl.getAttribute('aria-label') || '';
        const starMatch = aria.match(/(\d+)/);
        if (starMatch) rRating = parseInt(starMatch[1], 10);
      }
      const date = dateEl ? dateEl.innerText.trim() : 'Recente';

      if (text && rRating >= 4) {
        reviews.push({
          author,
          rating: rRating,
          text,
          date
        });
      }
    });

    return {
      title,
      category,
      address,
      phone,
      websiteUrl,
      instagramUrl,
      instagram,
      thumbnailUrl,
      photos: placePhotos,
      rating,
      reviewCount,
      mapsUrl: window.location.href,
      openingHours,
      mapEmbedUrl,
      coordinates,
      reviews
    };
  }

  function showToast(type, message) {
    const existing = document.querySelector('.billy-hunter-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = `billy-hunter-toast ${type}`;
    toast.innerHTML = `<span>${message}</span>`;

    document.body.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transition = 'opacity 0.4s ease';
      setTimeout(() => toast.remove(), 400);
    }, 4500);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initBillyHunter);
  } else {
    initBillyHunter();
  }

  const observer = new MutationObserver(() => {
    initBillyHunter();
  });
  observer.observe(document.body, { childList: true, subtree: true });
})();
